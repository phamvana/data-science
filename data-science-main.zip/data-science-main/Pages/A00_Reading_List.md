# Machine Learning & Data Science Reading List 
## Table of contents
- [AI Application](#ai-application)
- [Machine Learning Interview](#machine-learning-interview) 


## AI Application
- [How the biggest companies in the world design Machine Learning-powered applications](https://www.linkedin.com/pulse/how-biggest-companies-world-design-machine-daniel-bourke/?fbclid=IwAR1QdQIaeK72nKjpePNKv6sAZayqCp669lg2EjwfvtBx7v6orN1Kw5QOc5c)

[(Back to top)](#table-of-contents)
## Machine Learning Interview
- [Introduction to Machine Learning Interviews Book](https://huyenchip.com/ml-interviews-book/)

[(Back to top)](#table-of-contents)
